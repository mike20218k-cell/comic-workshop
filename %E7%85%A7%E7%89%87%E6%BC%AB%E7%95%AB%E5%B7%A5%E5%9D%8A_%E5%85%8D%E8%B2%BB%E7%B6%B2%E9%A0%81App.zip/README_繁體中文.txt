照片漫畫工坊｜免費網頁 App
================================

內容
- index.html：網頁程式
- manifest.webmanifest、sw.js：加入主畫面與離線快取設定

免費發布方式（使用 GitHub Pages）
1. 用 Safari 前往 https://github.com 並登入／註冊免費帳號。
2. 建立一個新的 Public repository，名稱可用 comic-workshop。
3. 將本資料夾內的 3 個檔案（index.html、manifest.webmanifest、sw.js）上傳到 repository 根目錄。
4. 在 repository 的 Settings → Pages → Build and deployment，選擇 Deploy from a branch。
5. Branch 選 main、資料夾選 /(root)，按 Save。
6. 等待 GitHub Pages 發布，網址會是 https://你的帳號.github.io/comic-workshop/

iPhone 安裝
1. 用 iPhone Safari 開啟上面的網址。
2. 點分享按鈕（方框向上箭頭）。
3. 選「加入主畫面」，再按「加入」。

使用
- 最多選 8 張照片。
- 選風格、排版，填標題與對話，再按「製作漫畫」。
- 儲存若沒有反應，請按「分享／儲存到照片」，在分享選單選「儲存影像」。
- 照片只在瀏覽器本機處理，不會上傳。

注意
- 這是免費網頁 App，不是 App Store 上架的原生 iPhone App。
- 目前的風格是濾鏡、漫畫框與版面效果，不是 AI 重新繪圖。
- GitHub Pages 免費方案適合公開靜態網站；請勿上傳私人照片到 GitHub，照片只在使用者手機選取即可。
